
initializer = MutualFundDataLoader()
## Get the List of all mutual funds
#all_mf_list = initializer.get_all_mf_list()
#print(all_mf_list)

## Get the list of mutual funds whose there is high probability for getting historical data
#eligible_mf_list = initializer.mf_eligible_for_historical()
#print(eligible_mf_list)
##Downloading Historical data for  Edelweiss Nifty Next 50 Index Fund - Regular Plan - IDCW

#nav_historical_data = initializer.get_historical_nav("150898", "2023-01-01", "2023-12-31")
#print(nav_historical_data)


##Get latest Nav for  Edelweiss Nifty Next 50 Index Fund - Regular Plan - IDCW

#latest_nav = initializer.get_latest_nav("150898")
#print(latest_nav)
